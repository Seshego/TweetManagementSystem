package service;

import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import model.TweetEntity;


@Stateless
@LocalBean
public class tweetEJB {

	@PersistenceContext
	private EntityManager em;
	
    public tweetEJB(){
        // TODO Auto-generated constructor stub
    }
    
    public void addNew(TweetEntity tweetEntity)
    {
    	System.out.println("Adding to database");
    	em.persist(tweetEntity);
    	System.out.println("=======================Tweet saved to DB=============");
		
    }
    @SuppressWarnings("unchecked")
	public List<TweetEntity> findAll() {
	
		return em.createQuery("SELECT Twit FROM tweet_tbl").getResultList();
	}

    
	public EntityManager getEm() {
		return em;
	}

	public void setEm(EntityManager em) {
		this.em = em;
	}
    

}
