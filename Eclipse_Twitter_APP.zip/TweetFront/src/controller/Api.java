package controller;
import javax.ws.rs.ApplicationPath;


@ApplicationPath("/api/")
public class Api {

}
