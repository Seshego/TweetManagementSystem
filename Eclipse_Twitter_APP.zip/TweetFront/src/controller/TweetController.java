package controller;



import java.util.ArrayList;
import java.util.List;


import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;
import javax.ws.rs.GET;
import javax.ws.rs.Path;

import model.Tweet;
import model.TweetEntity;
import service.tweetEJB;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.conf.ConfigurationBuilder;

@ManagedBean(name="tweetController")
@SessionScoped
@Path("/mytweets")
public class TweetController {
	@EJB
	tweetEJB tweetService;
	@ManagedProperty(value="#{tweet}")
	private Tweet tweet;

	public tweetEJB getTweetService() {
		return tweetService;
	}
	
	public void setTweetService(tweetEJB tweetService) {
		this.tweetService = tweetService;
	}
	public Tweet getTweet() {
		return tweet;
	}
	public void setTweet(Tweet tweet) {
		this.tweet = tweet;
	}

	public void addNewTweet()
	{
		System.out.println("In use!!");
		tweetService.addNew(tweet.getEntity());
		
		ConfigurationBuilder cb = new ConfigurationBuilder();
	    cb.setDebugEnabled(true)
	      .setOAuthConsumerKey("IxinpQLZuYJTkd7sg6y1bek4j")
	      .setOAuthConsumerSecret("y2NbYBzH1QtvuLdJ7aMFGaPEhcslIUKQk3iB3E3sxDIiEOoWs1")
	      .setOAuthAccessToken("131235369-lrBJBJudJ1fH01EuGePDhjvz0PImbevDRhDQOPI2")
	      .setOAuthAccessTokenSecret("NLfpFOucyXGKuW4nRtkwLIZy1zklMWxFd16AWrxCTzY9z");
	    TwitterFactory tf = new TwitterFactory(cb.build());
	    Twitter twit =(Twitter) tf.getInstance();
		try {
			twit.updateStatus(tweet.getTweetMSG());
			   System.out.println("Successfully tweeted!!!");
		          
		} catch (TwitterException e) {
			
			e.printStackTrace();
		}
		
	}

	@Path("getAllTweets")
	@GET

	public Iterable<TweetEntity> getAllTweets()
	{
		System.out.print("get all tweets");
		System.out.println(tweetService.findAll());
		return tweetService.findAll();
	}
	public String viewTweets() {

		System.out.println("Seshego");
		return "tweetList.xhtml";
	}

}
