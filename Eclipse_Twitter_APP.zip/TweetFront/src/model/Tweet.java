package model;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean(name="tweet")
@SessionScoped

public class Tweet {
	
	private String tweetMSG;


	public String getTweetMSG() {
		return tweetMSG;
	}


	public void setTweetMSG(String tweetMSG) {
		this.tweetMSG = tweetMSG;
	}



	public TweetEntity getEntity()
	{
		TweetEntity tweetentity = new TweetEntity();
		tweetentity.setTwit(tweetMSG);
		
		return tweetentity;
	}

}
